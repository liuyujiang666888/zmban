package com.jt.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

//最好与数据库中的字段一致
@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain=true)
public class User {
	
	private Integer id;
	private String name;
	private Integer age;
	private String sex;
}
