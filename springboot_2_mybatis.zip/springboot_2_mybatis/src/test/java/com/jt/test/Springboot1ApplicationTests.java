package com.jt.test;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.jt.mapper.UserMapper;
import com.jt.pojo.User;

//springBoot的测试类
@SpringBootTest
class Springboot1ApplicationTests {

	@Autowired	//动态注入
	private UserMapper userMapper;
	
	@Test
	public void testFind() {
		
		List<User> userList = userMapper.findAll();
		System.out.println(userList);
	}
	
}
