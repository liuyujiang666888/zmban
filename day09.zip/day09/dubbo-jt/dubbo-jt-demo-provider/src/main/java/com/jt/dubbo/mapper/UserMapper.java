package com.jt.dubbo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jt.dubbo.pojo.User;

public interface UserMapper extends BaseMapper<User>{
	
}
