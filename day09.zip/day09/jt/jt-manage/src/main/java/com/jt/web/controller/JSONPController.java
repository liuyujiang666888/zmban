package com.jt.web.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.jt.pojo.ItemDesc;
import com.jt.util.ObjectMapperUtil;

@RestController
public class JSONPController {
	
	//http://manage.jt.com/web/testJSONP?callback=jQuery1111036536630816827453_1577586557096&_=1577586557097
	public String jsonp(String callback) {
		ItemDesc itemDesc = new ItemDesc();
		itemDesc.setItemId(100L)
				.setItemDesc("您好JSONP");
		return callback+"("
				+ObjectMapperUtil.toJSON(itemDesc)
				+")";	
	}
	
	@RequestMapping("/web/testJSONP")
	public JSONPObject jsonpObject(String callback) {
		ItemDesc itemDesc = new ItemDesc();
		itemDesc.setItemId(100L)
				.setItemDesc("您好JSONP");
		return new JSONPObject(callback, itemDesc);
	}
	
	
	
	
	
}
