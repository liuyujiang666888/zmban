package com.jt.controller;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jt.pojo.Item;
import com.jt.pojo.ItemDesc;
import com.jt.service.ItemService;
import com.jt.vo.EasyUITable;
import com.jt.vo.SysResult;

@RestController	//整个类的返回值都是JSON
@RequestMapping("/item")
public class ItemController {
	
	@Autowired
	private ItemService itemService;
	
	/**
	 * 分页查询商品信息
	 * 原则:EasyUI中的JS提供了js插件.会自动的拼接当前分页信息
	 * http://localhost:8091/item/query?page=1&rows=20
	 */
	@RequestMapping("/query")
	@ResponseBody //将数据转化为JSON
	public EasyUITable findItemByPage(Integer page,Integer rows) {
		
		return itemService.findItemByPage(page,rows);
	}
	
	
	/**
	 * 商品新增
	 *url:c
	 * 参数:item对象的属性
	 * 返回值:SysResult对象 JSON
	 */
	@RequestMapping("/save")
	public SysResult saveItem(Item item,ItemDesc itemDesc) {
		/*try {
			itemService.saveItem(item);
			return SysResult.success();
		} catch (Exception e) {
			e.printStackTrace();
			return SysResult.fail();
		}*/
		itemService.saveItem(item,itemDesc);
		return SysResult.success();
		
	}
	
	
	/**
	 * 商品修改
	 * url地址:/item/update
	 *   参数: item属性
	 *   返回值:SysResultJSON的数据
	 */
	@RequestMapping("/update")
	public SysResult updateItem(Item item,ItemDesc itemDesc) {
		
		itemService.updateItem(item,itemDesc);
		return SysResult.success();
	}
	
	/**
	 *  商品删除
	 *  url: /item/delete
	 *     参数:  {"ids":ids}     101,102,103
	 *      返回值:  SysResult对象
	 */
	@RequestMapping("/delete")
	public SysResult deleteItems(Long[] ids) {
		
		itemService.deleteItems(ids);
		return SysResult.success();
	}
	
	
	/**
	 * url:/item/instock
	 *   参数: {"ids":ids}
	 *   返回值:SysResult
	 */
	@RequestMapping("instock")
	public SysResult instockItem(Long[] ids) {
		int status = 2;
		itemService.updateStatus(ids,status);
		return SysResult.success();
	}
	
	//上架
	@RequestMapping("reshelf")
	public SysResult reshelfItem(Long[] ids) {
		int status = 1;	
		itemService.updateStatus(ids,status);
		return SysResult.success();
	}
	
	/**
	 *  url地址: /item/query/item/desc/100100
	 *     参数: 接收itemId
	 *     返回值: SysResult对象
	 */
	@RequestMapping("/query/item/desc/{itemId}")
	public SysResult queryItemDesc(@PathVariable Long itemId) {
		
		ItemDesc itemDesc = itemService.findItemDescById(itemId);
		
		return SysResult.success(itemDesc);
	}
	
	
	
	
	
	
	
	
	
	
}
