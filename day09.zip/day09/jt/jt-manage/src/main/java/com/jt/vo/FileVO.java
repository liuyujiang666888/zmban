package com.jt.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileVO {
	
	private Integer error=0;	// 0正常 1错误
	private String url;			//图片虚拟路径
	private Integer width;		//宽度
	private Integer height;		//高度
	
}
