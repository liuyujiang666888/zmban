package com.jt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jt.pojo.ItemCat;
import com.jt.service.ItemCatService;
import com.jt.service.ItemService;
import com.jt.vo.EasyUITree;

@RestController
@RequestMapping("/item/cat")
public class ItemCatController {
	
	@Autowired
	private ItemCatService itemCatService;
	
	@RequestMapping("/queryItemName")
	public String findItemCatNameById(String itemCatId) {
		
		ItemCat itemCat = itemCatService.findItemCatById(itemCatId);
		return itemCat.getName();
	}
	
	/**
	 * 实现商品分类查询
	 * 如果是第一次请求则parentId=0
	 * 如果是展开节点,将该节点的Id当做参数发送?id=580
	 * easyUI中异步树加载控件
	 * 
	 * 树控件读取URL。子节点的加载依赖于父节点的状态。
	 * 当展开一个封闭的节点，如果节点没有加载子节点，
	 * 它将会把节点id的值作为http请求参数并命名为'id'，
	 * 通过URL发送到服务器上面检索子节点。


	 */
	@RequestMapping("/list")
	public List<EasyUITree> findItemCatByParentId(@RequestParam(name="id",defaultValue="0")Long parentId){
		
		return itemCatService.findItemCatByParentId(parentId);
		//return itemCatService.findItemCache(parentId);
	}
	
	
	
	
	
	
	
}
