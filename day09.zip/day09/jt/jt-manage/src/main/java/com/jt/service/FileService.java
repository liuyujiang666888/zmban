package com.jt.service;

import org.springframework.web.multipart.MultipartFile;

import com.jt.vo.FileVO;

public interface FileService {

	FileVO fileUpload(MultipartFile uploadFile);

}
