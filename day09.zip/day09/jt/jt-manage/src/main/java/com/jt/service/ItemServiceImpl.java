package com.jt.service;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.jt.mapper.ItemDescMapper;
import com.jt.mapper.ItemMapper;
import com.jt.pojo.Item;
import com.jt.pojo.ItemDesc;
import com.jt.vo.EasyUITable;

@Service
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	private ItemMapper itemMapper;
	@Autowired
	private ItemDescMapper itemDescMapper;

	@Override
	public EasyUITable findItemByPage(Integer page, Integer rows) {
		
		//1.查询商品总记录数
		int total = itemMapper.selectCount(null);
		/**
		 * 2.分页查询   每页20条
		 * select * from tb_item limit 起始位置,查询条数
		 * 第1页: select * from tb_item limit 0,20
		 * 第2页: select * from tb_item limit 20,20
		 * 第3页: select * from tb_item limit 40,20
		 * 第n页: select * from tb_item limit (n-1)*rows,rows
		 */
		int start = (page -1) * rows;
		List<Item> itemList = itemMapper.findITemByPage(start,rows);;
		return new EasyUITable(total, itemList);
	}

	@Transactional	//控制事务
	@Override
	public void saveItem(Item item,ItemDesc itemDesc) {
		item.setCreated(new Date())
			.setUpdated(item.getCreated());
		//保证数据时间一致的
		itemMapper.insert(item); 
		//数据入库之后才会有主键,能否将入库之后的主键动态的
		//回显 mybatis-plus已将自动实现.
		
		itemDesc.setItemId(item.getId())
				.setCreated(item.getCreated())
				.setUpdated(item.getCreated());
		itemDescMapper.insert(itemDesc);
	}

	@Transactional
	@Override
	public void updateItem(Item item,ItemDesc itemDesc) {
		
		item.setUpdated(new Date());
		itemMapper.updateById(item);
		
		itemDesc.setItemId(item.getId())
				.setUpdated(new Date());
		itemDescMapper.updateById(itemDesc);
	}
	
	@Transactional
	@Override
	public void deleteItems(Long[] ids) {
		List<Long> list = Arrays.asList(ids);
		itemMapper.deleteBatchIds(list);
		itemDescMapper.deleteBatchIds(list);
	}
	
	/**
	 * sql:update tb_item status=#{status},
	 * 	   updated=#{updated}
	 * 	   where id in (1001,1002,1003)
	 */
	@Override
	public void updateStatus(Long[] ids, int status) {
		Item item = new Item();
		item.setStatus(status)
			.setUpdated(new Date());
		
		UpdateWrapper<Item> updateWrapper = new UpdateWrapper<Item>();
		List<Long> longList = Arrays.asList(ids);
		updateWrapper.in("id", longList);
		itemMapper.update(item, updateWrapper);
	}

	@Override
	public ItemDesc findItemDescById(Long itemId) {
		
		return itemDescMapper.selectById(itemId);
	}

	@Override
	public Item findItemById(long itemId) {
		
		return itemMapper.selectById(itemId);
	}
	
}
