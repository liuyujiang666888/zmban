package com.jt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.jt.anno.Cache_Find;
import com.jt.mapper.ItemCatMapper;
import com.jt.pojo.ItemCat;
import com.jt.util.ObjectMapperUtil;
import com.jt.vo.EasyUITree;

import redis.clients.jedis.Jedis;

@Service
public class ItemCatServiceImpl implements ItemCatService {
	
	@Autowired
	private ItemCatMapper itemCatMapper;
	
	//允许懒加载,用户使用时调用.
	@Autowired(required=false)
	private Jedis jedis;

	@Override
	public ItemCat findItemCatById(String itemCatId) {
		
		return itemCatMapper.selectById(itemCatId);
	}
	
	/**
	 * 数据库数据itemCat转化为VO对象
	 */
	@Override
	@Cache_Find	//将该方法缓存处理
	public List<EasyUITree> findItemCatByParentId(long parentId) {
		List<ItemCat> catList = findItemCatList(parentId);
		List<EasyUITree> treeList = new ArrayList<>();
		for (ItemCat itemCat : catList) {
			EasyUITree tree = new EasyUITree();
			String  state = itemCat.getIsParent()?"closed":"open";
			tree.setId(itemCat.getId())
				.setText(itemCat.getName())
				.setState(state);
			treeList.add(tree);
		}
		return treeList;
	}

	private List<ItemCat> findItemCatList(long parentId) {
		QueryWrapper<ItemCat> queryWrapper = new QueryWrapper<ItemCat>();
		queryWrapper.eq("parent_id", parentId);
		return itemCatMapper.selectList(queryWrapper);
	}
	
	/**
	 * 1.根据根据key查询redis  变量key??
	 * 2.结果2种  
	 * 	  1: null
	 * 		 表示第一次查询数据,查询真实的数据库,将数据保存到redis中
	 * 		 方便以后使用.
	 * 	  2: !null
	 * 		获取json数据,转化为对象.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EasyUITree> findItemCache(Long parentId) {
		Long start = System.currentTimeMillis();
		
		String key = "ItemCatServiceImpl.findItemCache::"+parentId;
		String json = jedis.get(key);
		List<EasyUITree> treeList = new ArrayList<>();
		
		
		if(StringUtils.isEmpty(json)) {
			//表名第一次查询
			treeList = findItemCatByParentId(parentId);
			if(treeList.size()>0) {
				
				String listJSON = ObjectMapperUtil.toJSON(treeList);
				jedis.set(key, listJSON);
			}
			
			Long endTime = System.currentTimeMillis();
			System.out.println(endTime - start+"数据库查询毫秒数");
			
		}else {
			//将json串转化为对象
			treeList = ObjectMapperUtil.toObj(json,treeList.getClass());
			Long endTime = System.currentTimeMillis();
			System.out.println(endTime - start+"缓存查询毫秒数");
		}
		
		return treeList;
	}
	
	
	
	
	
	
}
