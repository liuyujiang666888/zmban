package com.jt.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jt.pojo.Item;
import com.jt.pojo.ItemDesc;
import com.jt.service.ItemService;
import com.jt.vo.SysResult;

@RestController //返回值要求JSON串
@RequestMapping("/web/item")
public class WebItemContorller {
	
	@Autowired
	private ItemService itemService;
	
	/**
	 * http://manage.jt.com/web/item/finditemById
	 * 参数:params.put("itemId", itemId+"");
	 * 返回值结果: 系统的返回值变量
	 * @return
	 */
	
	@RequestMapping("/finditemById")
	public SysResult findItemById(long itemId) {
		
		Item item = itemService.findItemById(itemId);
		if(item == null) {
			
			return SysResult.fail(); //201
		}
		
		return SysResult.success(item);
		
	}
	
	
	@RequestMapping("/finditemDescById")
	public ItemDesc findItemDescById(long itemId) {
		
		return itemService.findItemDescById(itemId);
	}
	
}
