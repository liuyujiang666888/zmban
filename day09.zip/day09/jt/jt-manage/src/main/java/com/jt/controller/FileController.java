package com.jt.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.jt.service.FileService;
import com.jt.vo.FileVO;

@RestController
public class FileController {
	
	@Autowired
	private FileService fileService;
	
	/**
	 * url:/file
	 *   参数: 提交的是图片信息  fileImage
	 * 返回值: 字符串
	 * @return
	 * @throws IOException 
	 * @throws IllegalStateException 
	 */
	@RequestMapping("/file")
	public String file(MultipartFile fileImage) throws IllegalStateException, IOException {
		File file = new File("E:\\jt-upload");
		if(!file.exists()) {
			file.mkdirs();	//文件不存在时,创建文件
		}
		
		//2.获取文件名称
		String fileName = fileImage.getOriginalFilename();
		
		//3.文件上传
		fileImage.transferTo(new File("E:\\jt-upload/"+fileName));
		return "文件上传成功!!!!";
	}
	
	
	/**
	 * 富文本编辑器文件上传
	 * 1.url地址  /pic/upload
	 * 2.参数名称  uploadFile
	 * 3.返回值:    FileVO
	 */
	@RequestMapping("/pic/upload")
	public FileVO fileUpload(MultipartFile uploadFile) {
		
		return fileService.fileUpload(uploadFile);
	}
	
	
	
	
	
	
	
	
	
}
