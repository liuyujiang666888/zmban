package com.jt.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.jt.vo.FileVO;

@Service
public class FileServiceImpl implements FileService {
	
	private String localDir = "E:/jt-upload/";
	private String urlPath = "http://image.jt.com/";
	/**
	 * 数据校验
	 * 	1.校验是否为图片类型  判断后缀
	 * 	2.校验是否为恶意程序  准备图片工具API
	 * 	3.分文件存储		     按照时间格式yyyy/MM/dd fastDFS
	 * 	4.保证文件名称不重复  uuid自定义文件名称
	 */
	
	/* (non-Javadoc)
	 * @see com.jt.service.FileService#fileUpload(org.springframework.web.multipart.MultipartFile)
	 */
	@Override
	public FileVO fileUpload(MultipartFile uploadFile) {
		FileVO fileVO = new FileVO();
		//1.判断文件后缀类型  xxx.jpg|xxx.JPG
		String fileName = uploadFile.getOriginalFilename();
		//将数据全部转化为小写.
		fileName = fileName.toLowerCase(); 
		if(!fileName.matches("^.+\\.(jpg|png|git)$")) {
			fileVO.setError(1);//表示文件上传有误
			return fileVO;
		}
		
		//2.校验是否为恶意成功
		try {
			BufferedImage bufferedImage = ImageIO.read(uploadFile.getInputStream());
			int height = bufferedImage.getHeight();
			int width = bufferedImage.getWidth();
			
			if(height==0 || width ==0) {
				fileVO.setError(1);
				return fileVO;
			}
			
			
			//3.分文件存储  yyyy/MM/dd
			String dateDir = new SimpleDateFormat("yyyy/MM/dd/").format(new Date());
			//形成文件存储根目录
			String localDirPath = localDir+dateDir;
			File dirFile = new File(localDirPath);
			if(!dirFile.exists()) {
				//如果文件不存在.则创建文件
				dirFile.mkdirs();
			}
			
			//4.动态生成文件名称. name.后缀
			String uuid = UUID.randomUUID().toString();
			int index = fileName.lastIndexOf(".");
			String type = fileName.substring(index);
			String realFileName = uuid+type;
			
			//dir+文件名称
			File file = new File(localDirPath+realFileName);
			uploadFile.transferTo(file);
			
			//准备数据返回值
			fileVO.setWidth(width);
			fileVO.setHeight(height);
			
			//为图片准备虚拟路径
			String realUrlPath = urlPath+dateDir+realFileName;
			fileVO.setUrl(realUrlPath);
		} catch (Exception e) {
			e.printStackTrace();
			fileVO.setError(1);
			return fileVO;
		}
		
		return fileVO;
	}

}
