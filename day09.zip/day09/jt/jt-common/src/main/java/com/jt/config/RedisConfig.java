package com.jt.config;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisSentinelPool;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedis;

@Configuration
@PropertySource("classpath:/properties/redis.properties")
public class RedisConfig {
	
	@Value("${redis.cluster.nodes}")
	private String nodes; //node,node
	
	
	@Scope("prototype")
	@Bean
	public JedisCluster cluster() {
		Set<HostAndPort> sets = new HashSet<>();
		String[] array = nodes.split(",");
		for (String node : array) {
			String host = node.split(":")[0];
			int port = Integer.parseInt(node.split(":")[1]);
			sets.add(new HostAndPort(host, port));
		}
		
		return new JedisCluster(sets);
	}
	
}
	
	/*//实现redis哨兵配置
	@Value("${redis.sentinels}")
	private String nodes;
	
	
	@Bean
	public JedisSentinelPool pool() {
		Set<String> set = new HashSet<String>();
		set.add(nodes);
		return new JedisSentinelPool("mymaster", set);
	}
	
	//用户什么时候使用,对象什么时候创建
	@Bean
	@Scope("prototype") //多例对象
	public Jedis jedis(JedisSentinelPool pool) {
		
		
		return pool.getResource();
	}*/

	
	/*@Value("${redis.nodes}")
	private String nodes;    //node,node,node
	
	//redis分片
	@Bean
	@Scope("prototype") //多例对象
	public ShardedJedis shardedJedis() {
		List<JedisShardInfo> list = new ArrayList<>();
		String[] arrayNode = nodes.split(",");
		for (String node : arrayNode) { //host:port
			String host = node.split(":")[0];
			int port = Integer.parseInt(node.split(":")[1]);
			list.add(new JedisShardInfo(host, port));
		}
		
		return new ShardedJedis(list);
	}*/

	
	
	
	
	
	
	/*@Value("${redis.host}")
	private String host;
	@Value("${redis.port}")
	private Integer port;
	//将实例化好的对象交给容器管理
	@Bean
	@Scope("prototype") //多例对象
	public Jedis jedis() {
		
		return new Jedis(host, port);
	}*/
