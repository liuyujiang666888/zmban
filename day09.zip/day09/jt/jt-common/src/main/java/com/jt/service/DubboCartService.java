package com.jt.service;

import java.util.List;

import com.jt.pojo.Cart;

public interface DubboCartService {

	List<Cart> findCartList(Long userId);
	//定义购物车接口

	void updateCartNum(Cart cart);

	void deleteCart(Cart cart);

	void addCart(Cart cart);
}
