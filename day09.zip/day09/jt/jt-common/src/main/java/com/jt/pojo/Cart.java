package com.jt.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;
import lombok.experimental.Accessors;

@TableName("tb_cart")
@Data //get/set
@Accessors(chain=true)
public class Cart extends BasePojo{
	@TableId(type=IdType.AUTO)
	private Long id;
	private Long userId;
	private Long itemId;  //userId和itemId共同确定用户的唯一购买行为
	private String itemTitle;
	private String itemImage;
	private Long itemPrice;
	private Integer num;
	
}
