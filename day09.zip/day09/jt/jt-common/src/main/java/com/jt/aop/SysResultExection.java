package com.jt.aop;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.jt.vo.SysResult;

@RestControllerAdvice 	//定义异常通知
public class SysResultExection {
	
	@ExceptionHandler(RuntimeException.class)
	public SysResult fail(Exception exception) {
		exception.printStackTrace();
		return SysResult.fail();
	}

}
