package com.jt.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.jt.anno.Cache_Find;
import com.jt.util.ObjectMapperUtil;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.ShardedJedis;

@Component  //将对象交给容器管理
@Aspect		//标识我是一个切面
public class CacheAOP {
	
	@Autowired(required=false)
	private JedisCluster jedis;
	//private Jedis jedis;	//哨兵配置
	//private ShardedJedis jedis;
	
	//private Jedis jedis;
	/**
	 * 1.如何标识 该方法需要使用缓存  自定义注解
	 * 2.自定义注解的属性  
	 * 		key:用户可以指定,如果不指定则自动生成.
	 * 		value:不需要指定,因为方法的返回值可以当做value
	 * 		seconds: 认为的设定超时时间 默认值0  !0.用户需要指定过期时间
	 * 3.切入点表达式 拦截自己的注解.
	 * 4.由于缓存业务,需要控制目标方法执行,所以使用环绕通知.
	 * 
	 */
	
	
	/**
	 * key的生成策略:  包名.类名.方法名::第一个参数
	 * 	 
	 * @param cacheFind
	 * @return
	 */
	@SuppressWarnings("unchecked")
	//拦截自定义注解
	@Around("@annotation(cacheFind)")
	public Object around(ProceedingJoinPoint joinPoint,Cache_Find cacheFind) {
		//获取当前方法的类名 包路径.类型
		String className =
				joinPoint.getSignature().getDeclaringTypeName();
		String methodName = 
				joinPoint.getSignature().getName();
		Object argOne = joinPoint.getArgs()[0];
		String key = className+"."+methodName+"::"+argOne;
		
		String result = jedis.get(key);
		
		Object obj = null;
		try {
			
			if(StringUtils.isEmpty(result)) {
				//标识缓存中没有数据 
				obj = joinPoint.proceed(); //执行业务逻辑
				
				if(obj!=null) {
					
					String json = ObjectMapperUtil.toJSON(obj);
					
					if(cacheFind.seconds() ==0) {
						jedis.set(key, json);
					}else {
						jedis.setex(key, cacheFind.seconds(), json);
					}
				}
				System.out.println("AOP查询数据库!!!!");
			}else {
				//表示缓存服务器中有数据.
				MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
				Class returnType = methodSignature.getReturnType();
				obj = ObjectMapperUtil.toObj(result,returnType);
				System.out.println("AOP查询缓存!!!!");
			}
			
		} catch (Throwable e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		
		return obj;
	}
	
	
	
	
	
}
