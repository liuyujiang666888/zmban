package com.jt.pojo;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;
import lombok.experimental.Accessors;

@TableName("tb_item_desc")
@Data	//重写toString 方法时 只会添加自己的属性
@Accessors(chain=true)
public class ItemDesc extends BasePojo{
	@TableId	//标识主键 与商品表id是一致的
	private Long itemId;
	private String itemDesc;
	
}
