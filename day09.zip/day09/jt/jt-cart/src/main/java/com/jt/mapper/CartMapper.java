package com.jt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jt.pojo.Cart;
import com.jt.pojo.User;

public interface CartMapper extends BaseMapper<Cart>{
	
}
