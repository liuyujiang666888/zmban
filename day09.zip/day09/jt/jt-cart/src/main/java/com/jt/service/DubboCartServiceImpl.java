package com.jt.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.jt.mapper.CartMapper;
import com.jt.pojo.Cart;

@Service
public class DubboCartServiceImpl implements DubboCartService {
	
	@Autowired
	private CartMapper cartMapper;

	@Override
	public List<Cart> findCartList(Long userId) {
		QueryWrapper<Cart> queryWrapper = new QueryWrapper<>();
		queryWrapper.eq("user_id", userId);
		return cartMapper.selectList(queryWrapper);
	}

	
	/**
	 * sql: update tb_cart set num=#{num},updated=#{updated}
	 * 		where item_id=#{itemId} and user_id = #{userId}
	 */
	@Override
	public void updateCartNum(Cart cart) {
		Cart cartTmpe = new Cart();
		cartTmpe.setNum(cart.getNum())
				.setUpdated(new Date());
		UpdateWrapper<Cart> updateWrapper = new UpdateWrapper<Cart>();
		updateWrapper.eq("item_id", cart.getItemId())
					 .eq("user_id", cart.getUserId());
		cartMapper.update(cartTmpe, updateWrapper);
		
	}


	@Override
	public void deleteCart(Cart cart) {
		//根据对象中不为null的属性当做where条件
		QueryWrapper<Cart> queryWrapper = 
						new QueryWrapper<Cart>(cart);
		cartMapper.delete(queryWrapper);
	}

	/**
	 * 1.如果用户没有购买过该商品 则新增
	 * 2.如果用户购买过该商品,则更新
	 */
	@Override
	public void addCart(Cart cart) {
		
		QueryWrapper<Cart> queryWrapper = new QueryWrapper<Cart>();
		queryWrapper.eq("user_id", cart.getUserId())
					.eq("item_id", cart.getItemId());
		Cart cartDB = cartMapper.selectOne(queryWrapper);
		if(cartDB == null) {
			cart.setCreated(new Date())
				.setUpdated(cart.getCreated());
			cartMapper.insert(cart);
		}else {
			//更新  num
			int num = cart.getNum() + cartDB.getNum();
			cartDB.setNum(num)
				 .setUpdated(new Date());
			cartMapper.updateById(cartDB);
		}
	}
	
	
	
	
	
	
	
	
	
	
}
